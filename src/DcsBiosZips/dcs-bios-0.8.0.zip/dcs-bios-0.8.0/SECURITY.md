# Security Policy for dcs-bios

### Supported Versions

Openbeta

### Reporting a Vulnerability

Use Github Issue to report a vulnerability.
