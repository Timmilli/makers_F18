module("Input", package.seeall)

--- @abstract
--- @class Input
--- @field interface InputType
--- @field description string
local Input = {}

return Input
