module("Log", package.seeall)

--- @class Log
local Log = {}

--- mock
--- @param str string
function Log:log(str) end

return Log
