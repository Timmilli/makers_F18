# Security Policy for dcs-bios

### Supported Versions

The latest release version will be kept patched against security vulnerabilities. Due to the nature of dcs-bios, past versions are not supported.

### Reporting a Vulnerability

**Do not report security issues via GitHub**. Please contact a staff member on our [Discord](https://discord.gg/5svGwKX) if you wish to report a security vulnerability.
